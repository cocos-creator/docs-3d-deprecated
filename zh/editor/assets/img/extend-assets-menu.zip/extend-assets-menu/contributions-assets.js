const pkg = require("./package.json");

module.exports = {
  Drop: [
    {
      type: "my-defined-asset-type-for-drop",
      message: "drop-asset",
    },
  ],
  Menu: [
    {
      path: "create",
      label: Editor.I18n.t('extend-assets-menu.menu.createAsset'),
      message: "create-asset",
    },
    {
      path: "asset",
      label: Editor.I18n.t('extend-assets-menu.menu.assetCommand'),
      submenu: [
        {
          label: Editor.I18n.t('extend-assets-menu.menu.runCommand'),
          message: "asset-command",
        },
      ],
    },
  ],
};
