"use strict";

module.exports = {
  title: "扩展资源面板菜单示例",

  menu: {
    createAsset: "按我的方式创建某种资源",
    dropMeToAssets: "把我拖到资源面板，会有回调",
    assetCommand: "我自定义的资源右击菜单行为",
    runCommand: "点击执行",
  },

  method: {
    dropAsset: "Assets 面板已成功执行了您的自定义拖拽行为，并反馈了数据：",
    createAsset:
      "Assets 面板右击菜单已执行了预设的自定义创建资源指令，并反馈了数据：",
    assetCommand:
      "Assets 面板右击菜单已执行了预设的自定义资源指令，并反馈了数据：",
  },
};
